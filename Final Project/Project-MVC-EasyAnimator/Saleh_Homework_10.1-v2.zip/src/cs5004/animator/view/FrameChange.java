package cs5004.animator.view;

/**
 * Represents the type of change being made. //TODO: Complete this for assignment part 3.
 */
public enum FrameChange {
  EDIT, ADD, DELETE
}
