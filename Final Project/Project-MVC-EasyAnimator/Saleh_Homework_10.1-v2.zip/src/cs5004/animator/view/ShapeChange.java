package cs5004.animator.view;

/**
 * This enum class class represents larger shape changes in the animation.
 */
public enum ShapeChange {
  DELETE, ADD
}
