package cs5004.animator.model;

/**
 * Enums for the shapes that are used in this animation.
 */
public enum Shapes {
  RECTANGLE, ELLIPSE
}
