/**
 * This enum class contains the possible motions that a shape can have.
 */
public enum Motions {
  SCALE, MOVE, COLOR
}
