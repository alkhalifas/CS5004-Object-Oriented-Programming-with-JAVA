package cs5004.animator.model;

/**
 * Enums for the motions that are used in this animation project.
 */
public enum Motions {
  MOVE, CHANGECOLOR, SCALE
}
