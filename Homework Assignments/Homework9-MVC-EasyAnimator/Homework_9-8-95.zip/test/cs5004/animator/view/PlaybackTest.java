package cs5004.animator.view;


/**
 * Testing file for checking the playback terminal command in main.
 */
public class PlaybackTest {

//  @Test
//  public void testMain1() {
//    EasyAnimator.main(new String[]{"-view", "playback", "-in", "./starter_code/toh-3.txt"});
//  }
}