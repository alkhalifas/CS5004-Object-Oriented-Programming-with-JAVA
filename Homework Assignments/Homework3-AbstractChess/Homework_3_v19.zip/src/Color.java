/**
 * Represents the color of the chess pieces.
 */
public enum Color {
  BLACK, WHITE
}