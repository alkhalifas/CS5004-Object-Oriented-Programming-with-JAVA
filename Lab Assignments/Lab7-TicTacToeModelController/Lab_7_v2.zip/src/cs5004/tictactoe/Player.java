package cs5004.tictactoe;

/**
 * Represents an Enum class consisting of an empty player, an X player, and an O player.
 */
public enum Player { EMPTY, X, O }
